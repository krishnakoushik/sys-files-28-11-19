package com.example.CustomerServices;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class CustomerService {
	
	@Autowired
	RestTemplate restTemplate;
	
	@GetMapping("/placeorder/{price}/{time}")
	public String callService(@PathVariable("price") int price,@PathVariable("time") int time)
	{
		
		String url="http://RESTAURENT-SERVICES/order/"+price+"/"+time;
		System.out.println(url);
		return restTemplate.getForObject(url, String.class);
		
		
	}

}
