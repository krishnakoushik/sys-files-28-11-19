package com.example.RestaurentServices;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
@RestController
public class Restaurent {
	@GetMapping("/open")
	public String restaurantOpen()
	{
		return "New Restaurent";
	}

	@GetMapping("/order/{price}/{time}")
	@HystrixCommand(commandProperties = {
            @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "500")
        },fallbackMethod = "handler")
	public String placeOrder(@PathVariable("price") int price,@PathVariable("time") int time)
	{
		
		System.out.println("IN RESTAURENT");
		if(price < 500)
		{
			
			try {
				Thread.sleep(time);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return "Order Confirm";
		}
		 throw new ArithmeticException();
	
	}
	
	
	// must have same signature as exception method
	public String handler(int x,int y)
	{
		
		System.out.println("IN FALLBACK");
		return "Try After Some time";
	}
}
