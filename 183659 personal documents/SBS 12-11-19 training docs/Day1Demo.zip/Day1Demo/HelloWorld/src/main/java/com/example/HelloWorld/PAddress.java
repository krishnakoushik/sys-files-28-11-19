package com.example.HelloWorld;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Service
@Profile("paddress")
public class PAddress implements IAddress {

	@Override
	public void publishAddress() {
		// TODO Auto-generated method stub
		System.out.println("PADDRESS");
	}

}
