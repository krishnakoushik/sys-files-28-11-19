package com.example.HelloWorld;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
/*@EnableAutoConfiguration
@ComponentScan("com.example.HelloWorld")
@SpringBootConfiguration*/
public class HelloWorldApplication {

	public static void main(String[] args) {
	ConfigurableApplicationContext ctx=	SpringApplication.run(HelloWorldApplication.class, args);
	
	Employee e=ctx.getBean("employee",Employee.class);
	System.out.println(e.sayHello());
	}

}
