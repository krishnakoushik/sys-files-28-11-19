package com.example.HelloWorld;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Service
@Profile("laddress")
public class LAddress implements IAddress {

	@Override
	public void publishAddress() {
		// TODO Auto-generated method stub
		System.out.println("LocalADDRESS");
	}

}
