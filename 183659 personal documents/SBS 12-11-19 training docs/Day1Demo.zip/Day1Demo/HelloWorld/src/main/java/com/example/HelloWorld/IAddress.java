package com.example.HelloWorld;

public interface IAddress {
	
	public void publishAddress();

}
