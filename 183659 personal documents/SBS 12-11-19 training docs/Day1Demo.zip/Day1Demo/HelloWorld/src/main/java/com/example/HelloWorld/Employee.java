package com.example.HelloWorld;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class Employee {
	
	@Autowired
	
	IAddress iAddress;
	public String sayHello()
	{
		iAddress.publishAddress();
		return "Hello World";
	}

}
