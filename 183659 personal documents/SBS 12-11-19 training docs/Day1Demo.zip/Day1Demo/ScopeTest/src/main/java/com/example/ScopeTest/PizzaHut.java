package com.example.ScopeTest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
@Service
@Scope("singleton")
public class PizzaHut {
	@Autowired
	Pizza pizza;
	
public PizzaHut() {
	// TODO Auto-generated constructor stub
	
	System.out.println("Pizza Hut Open");
}


public String orderPizza()
{
	return pizza.makePizza();
}


}
