package com.example.ScopeTest;

import java.io.Serializable;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Service;

@Service
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS,value =  "prototype")
public  class Pizza {
	
	public Pizza() {
		// TODO Auto-generated constructor stub
		
		System.out.println("Pizza ready");
	}

	
	
	public  String  makePizza() {
		return "Testy Pizza on the way";
		
	}
}
