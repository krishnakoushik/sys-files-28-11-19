package com.example.ScopeTest;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

@Service
@Scope("prototype")
public class Customer {
	
	PizzaHut pizzaHut;

	public Customer(PizzaHut pizzaHut) {
		super();
		this.pizzaHut = pizzaHut;
	}
	
	public String orderPizza()
	{
		return pizzaHut.orderPizza();
	}

}
