package com.example.ScopeTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class ScopeTestApplication {

	public static void main(String[] args) {
	ConfigurableApplicationContext ctx=	SpringApplication.run(ScopeTestApplication.class, args);
	
	Customer cust1=ctx.getBean("customer",Customer.class);
	System.out.println(cust1.orderPizza());
	
	Customer cust2=ctx.getBean("customer",Customer.class);
	System.out.println(cust2.orderPizza());
	}

}
