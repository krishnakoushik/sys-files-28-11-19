package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class FeignClient {
	 @Autowired
	    private GreetingClient greetingClient;
	 @RequestMapping("/greeting")
	    public String greeting(Model model) {
		 System.out.println("HELLO WORLD");
	        model.addAttribute("greeting", greetingClient.greeting());
	        System.out.println(greetingClient.greeting().toUpperCase());
	        return "greeting-view";
	    }
}
