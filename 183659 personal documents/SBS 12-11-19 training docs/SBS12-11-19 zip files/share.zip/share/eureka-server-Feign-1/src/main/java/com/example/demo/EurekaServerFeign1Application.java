package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EurekaServerFeign1Application {

	public static void main(String[] args) {
		SpringApplication.run(EurekaServerFeign1Application.class, args);
	}

}

