package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


@RestController

public class AccountClient {
	
	@Autowired
	StoreData client;
		
	@PostMapping(value= "/user", consumes="application/json")
	
	public String invokeCreateAccount(@RequestBody Account act)
	{
	
	    
        String response= client.getMessage(act);
        
	
	return response;
	}

}
