package com.example.demo;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
@FeignClient("http://api/SERVER-SERVICE") //http://api/server
public interface StoreData {

	@RequestMapping(value="create",method=RequestMethod.POST,produces = "application/json")
	public String getMessage(Account act);
}
